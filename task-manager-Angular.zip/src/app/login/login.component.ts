import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-login',
  template: `
    <h2>Login</h2>
    <button (click)="login()">Login</button>
  `
})
export default class LoginComponent {
  constructor(private router: Router) {}
  login() {
    this.router.navigate(['/dashboard']);
  }
}
