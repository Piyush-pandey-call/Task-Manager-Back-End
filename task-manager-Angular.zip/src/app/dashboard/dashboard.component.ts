import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  template: '<h2>Dashboard</h2>'
})
export default class DashboardComponent {}
